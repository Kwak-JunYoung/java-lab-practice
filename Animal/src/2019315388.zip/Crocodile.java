final class Crocodile extends Reptile{
	
	Crocodile(String Name, float Weight) {
		super(Name, Weight);
	}

	String getFood() {
		return "Meat";
	}
	
}